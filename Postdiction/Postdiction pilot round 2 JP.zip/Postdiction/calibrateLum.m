% This version of calibrate luminance is adjusted to include BOTH rgb and
% luminance terms in the calibration of a given contrast value - this
% calculates the luminance for every rgb value.
function [background, Lmin_rgb, Lmax_rgb, Lmin, Lmax, lum] = calibrateLum(contrast)

global environment;

rgb =          [0        30      60      90      120     150     180     190     210     220     230     240     250     255];

if strcmp(environment,'xx') || strcmp(environment,'xxx')
    % made-up luminance values for the MRI projector.
        rgb         = [0        30      60      90      120     150     180     190     200     210     220     230     240     250     255];
        lum(1,:)    = [0.7      13.6    78.5    192     333     490     667     732     784     833     890     960     1000    1045    1060];
    lum = mean(lum,1);
elseif strcmp(environment,'xxxx')
    % use made-up values for my workstation.
    lum(1,:) =     [0.27  4.1    24.6   63.8   109     163     224     243     286     302     317     325     326     327];
	lum = mean(lum,1);
elseif strcmp(environment,'xxxxx')
	% use made-up values for my macbook.
	lum(1,:) =     [0.27  4.1    24.6   63.8   109     163     224     243     286     302     317     325     326     327];
	lum = mean(lum,1);
else
    % not a calibrated environment.
    %disp('Warning: no luminance values found!');
    lum(1,:) = rgb;
    lum = mean(lum,1);
end

% interpolate over the whole rgb range
lum = interp1(rgb,lum,0:255,'pchip');
%figure; plot(lum)

%middle of the luminance range (now 1/3 of max brightness):
% medium_lum = (min(lum) + max(lum))/2;
% 1/3 of max brightness
background_lum = (min(lum) + max(lum))/3;
lum_diff = abs(lum - background_lum);
[val ind] = min(lum_diff);
background = ind - 1; %ind is 1-256 and need 0-255

if exist('contrast', 'var')
%     % for gratings; use Michelson contrast
%     Lmin = medium_lum - (medium_lum-min(lum))*contrast;
%     Lmax = medium_lum + (max(lum)-medium_lum)*contrast;
%     
%     lum_diff = abs(lum - Lmin);
%     [val ind] = min(lum_diff);
%     Lmin_rgb = ind - 1; %ind is 1-256 and need 0-255
%     
%     lum_diff = abs(lum - Lmax);
%     [val ind] = min(lum_diff);
%     Lmax_rgb = ind - 1; %ind is 1-256 and need 0-255 
    
    % PK: for the contrast of a bright flash on a dark background; use
    % Weber contrast
    Lmax = (contrast+1)*background_lum;
    lum_diff = abs(lum - Lmax);
    [val ind] = min(lum_diff);
    Lmax_rgb = ind - 1; %ind is 1-256 and need 0-255
    
    % Don't need Lmin and Lmin_rgb, just initialise to 0.
    Lmin=0; Lmin_rgb=0;
end



%plot(0:255,lum)
